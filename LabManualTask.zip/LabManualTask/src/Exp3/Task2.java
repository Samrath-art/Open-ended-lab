package Exp3;

public class Task2 {
	// LinkedList class with Node class defined
	
	    // Node class for representing each element in the linked list
	    class Node {
	        int data;
	        Node next;

	        // Constructor to initialize the node with data
	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    Node head;

	    // Method to add a node at the end of the list
	    public void append(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	            return;
	        }
	        Node current = head;
	        while (current.next != null) {
	            current = current.next;
	        }
	        current.next = newNode;
	    }

	    // Method to find the middle element using the two-pointer technique
	    public void findMiddle() {
	        if (head == null) {
	            System.out.println("The list is empty.");
	            return;
	        }

	        Node slow = head;
	        Node fast = head;

	        // Traverse the list with slow and fast pointers
	        while (fast != null && fast.next != null) {
	            slow = slow.next;  // Move slow pointer one step
	            fast = fast.next.next;  // Move fast pointer two steps
	        }

	        // slow will now be at the middle element
	        System.out.println("Middle Element: " + slow.data);
	    }

	    // Method to display the linked list
	    public void printList() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	        Task2 list = new Task2();
	        list.append(10);
	        list.append(20);
	        list.append(30);
	        list.append(40);
	        list.append(50);

	        System.out.println("Input List: ");
	        list.printList();

	        list.findMiddle();  // Output: Middle Element: 30
	    }
	}


