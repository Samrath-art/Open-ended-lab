package Exp5;

public class Task3 {
	

	    // Recursive method to solve Tower of Hanoi
	    public static void towerOfHanoi(int n, char fromRod, char toRod, char auxRod) {
	        // Base case: If only one disk, move it directly
	        if (n == 1) {
	            System.out.println("Move disk 1 from " + fromRod + " to " + toRod);
	            return;
	        }

	        // Move n-1 disks from 'fromRod' to 'auxRod', using 'toRod' as auxiliary
	        towerOfHanoi(n - 1, fromRod, auxRod, toRod);

	        // Move the nth disk from 'fromRod' to 'toRod'
	        System.out.println("Move disk " + n + " from " + fromRod + " to " + toRod);

	        // Move n-1 disks from 'auxRod' to 'toRod', using 'fromRod' as auxiliary
	        towerOfHanoi(n - 1, auxRod, toRod, fromRod);
	    }

	    public static void main(String[] args) {
	        int n = 3; // Number of disks
	        towerOfHanoi(n, 'A', 'C', 'B'); // From A to C using B as auxiliary
	    }
	}


