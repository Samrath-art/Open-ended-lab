package Exp5;

public class Task2 {
	

	    public static double power(int base, int exponent) {
	        // Base case: If the exponent is 0, return 1
	        if (exponent == 0) {
	            return 1;
	        }

	        // If the exponent is negative, calculate the reciprocal
	        if (exponent < 0) {
	            return 1 / power(base, -exponent);
	        }

	        // Recursive case: base^exponent = base * base^(exponent-1)
	        return base * power(base, exponent - 1);
	    }

	    public static void main(String[] args) {
	        System.out.println("power(2, 3) → " + power(2, 3));  // Expected output: 8
	        System.out.println("power(5, -2) → " + power(5, -2));  // Expected output: 0.04
	    }
	}


