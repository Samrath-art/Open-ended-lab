package Exp4;

public class Task1 {
	
	    class Node {
	        int data;
	        Node next;
	        Node prev;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	            this.prev = null;
	        }
	    }

	    Node head;

	    // Method to insert a node at a specific position
	    public void insertAtPosition(int data, int position) {
	        Node newNode = new Node(data);

	        // If inserting at the beginning (position 0)
	        if (position == 0) {
	            newNode.next = head;
	            if (head != null) {
	                head.prev = newNode;
	            }
	            head = newNode;
	            return;
	        }

	        Node current = head;
	        int index = 0;

	        // Traverse the list to find the position
	        while (current != null && index < position - 1) {
	            current = current.next;
	            index++;
	        }

	        // If the position is greater than the length of the list
	        if (current == null) {
	            System.out.println("Position out of range.");
	            return;
	        }

	        // Insert the new node at the desired position
	        newNode.next = current.next;
	        newNode.prev = current;

	        // If inserting not at the end
	        if (current.next != null) {
	            current.next.prev = newNode;
	        }

	        current.next = newNode;
	    }

	    // Method to print the list
	    public void printList() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	        Task1 list = new Task1();
	        list.head = new Task1().new Node(10);
	        list.head.next = new Task1().new Node(20);
	        list.head.next.prev = list.head;
	        list.head.next.next = new Task1().new Node(40);
	        list.head.next.next.prev = list.head.next;

	        System.out.println("Input List: ");
	        list.printList();

	        list.insertAtPosition(30, 2);
	        System.out.println("List after insertion: ");
	        list.printList();  // Expected output: 10 -> 20 -> 30 -> 40 -> null
	    }
	}


