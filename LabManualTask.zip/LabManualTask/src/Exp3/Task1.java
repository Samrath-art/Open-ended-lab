package Exp3;

public class Task1 {
    Node head;

    // Node class for linked list
    class Node {
        int data;
        Node next;

        // Constructor
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Add a new node at the beginning of the linked list
    public void addFirst(int data) {
        Node newNode = new Node(data);  // Create a new node
        if (head == null) {
            head = newNode;  // If the list is empty, new node becomes the head
        } else {
            newNode.next = head;  // Point new node's next to the current head
            head = newNode;  // Move the head to the new node
        }
    }

    // Print the linked list
    public void print() {
        Node currNode = head;
        while (currNode != null) {
            System.out.print(currNode.data + " -> ");  // Print data of current node
            currNode = currNode.next;  // Move to the next node
        }
        System.out.println("null");  // End of the list
    }public void reverse() {
    	   Node prev = null;
           Node curr = head;
           Node next = null;

           while (curr != null) {
               next = curr.next;  // Save next node
               curr.next = prev;  // Reverse current node's pointer
               prev = curr;       // Move prev and curr one step forward
               curr = next;
           }
           
           head = prev;  // Update head to the new first node
       }
    

    public static void main(String[] args) {
        // Create an object of Task1 to test linked list functionality
        Task1 obj = new Task1();
        obj.addFirst(40);  // Add nodes
        obj.addFirst(30);
        obj.addFirst(20);
        obj.addFirst(10);
        obj.print(); 
        obj.reverse();
        obj.print();// Print the list
    }
}
