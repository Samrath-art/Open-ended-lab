package Exp4;

public class Task2 {
	
	    class Node {
	        int data;
	        Node next;
	        Node prev;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	            this.prev = null;
	        }
	    }

	    Node head;

	    // Method to find the position of a value in the list
	    public int find(int value) {
	        Node current = head;
	        int position = 0;

	        while (current != null) {
	            if (current.data == value) {
	                return position;
	            }
	            current = current.next;
	            position++;
	        }
	        return -1;  // Value not found
	    }

	    // Method to count occurrences of a value in the list
	    public int countOccurrences(int value) {
	        Node current = head;
	        int count = 0;

	        while (current != null) {
	            if (current.data == value) {
	                count++;
	            }
	            current = current.next;
	        }
	        return count;
	    }

	    // Method to print the list
	    public void printList() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	        Task2 list = new Task2();
	        list.head = new Task2().new Node(10);
	        list.head.next = new Task2().new Node(20);
	        list.head.next.prev = list.head;
	        list.head.next.next = new Task2().new Node(30);
	        list.head.next.next.prev = list.head.next;
	        list.head.next.next.next = new Task2().new Node(20);
	        list.head.next.next.next.prev = list.head.next.next;

	        System.out.println("Input List: ");
	        list.printList();

	        System.out.println("Find position of 30: " + list.find(30));  // Expected output: Position 2
	        System.out.println("Count occurrences of 20: " + list.countOccurrences(20));  // Expected output: 2
	    }
	}


