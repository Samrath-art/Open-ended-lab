package Exp1;

public class Task3 {

    // Method to find and print all pairs of numbers in the array that add up to the target value
    public static void pair(int[] arr, int target) {
        // Outer loop to iterate over the elements in the array
        for (int i = 0; i < arr.length; i++) {
            // Inner loop to check for pairs with the element at index 'i'
            for (int j = i + 1; j < arr.length; j++) {
                // If the sum of the current pair equals the target, print the pair
                if (arr[i] + arr[j] == target) {
                    System.out.println("(" + arr[i] + "," + arr[j] + ")");
                }
            }
        }
    }

    public static void main(String[] args) {
        // Sample array of integers
        int[] arr = {1, 2, 3, 4, 5};
        // Target value we are checking for pair sums
        pair(arr, 6);  // Call the pair method to find all pairs that sum to 6
    }
}
