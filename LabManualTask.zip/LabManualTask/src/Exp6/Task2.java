package Exp6;

public class Task2 {

    // Inner class to represent an element with its priority

	    private int[][] queue;  // To store the queue elements as pairs of [value, priority]
	    private int size;  // To keep track of the number of elements in the queue

	    // Constructor to initialize the queue with a capacity of 10 elements
	    public Task2() {
	        queue = new int[10][2]; // Each element will be a pair: [value, priority]
	        size = 0;
	    }

	    // Enqueue method to add an element with a given priority
	    public void enqueue(int value, int priority) {
	        // If the queue is full, double its size
	        if (size == queue.length) {
	            int[][] newQueue = new int[queue.length * 2][2];
	            for (int i = 0; i < queue.length; i++) {
	                newQueue[i] = queue[i];
	            }
	            queue = newQueue;
	        }

	        // Add the new element at the end of the queue
	        queue[size][0] = value;
	        queue[size][1] = priority;
	        size++;

	        // Manually sort the queue based on priority (highest priority first)
	        for (int i = 0; i < size - 1; i++) {
	            for (int j = i + 1; j < size; j++) {
	                if (queue[i][1] < queue[j][1]) {
	                    // Swap elements if the priority of the i-th element is lower than the j-th element
	                    int[] temp = queue[i];
	                    queue[i] = queue[j];
	                    queue[j] = temp;
	                }
	            }
	        }
	    }

	    // Dequeue method to remove and return the element with the highest priority
	    public int dequeue() {
	        if (isEmpty()) {
	            throw new IllegalStateException("Queue is empty.");
	        }

	        // The first element has the highest priority after sorting
	        int highestPriorityValue = queue[0][0];

	        // Shift elements to the left to remove the first element
	        for (int i = 1; i < size; i++) {
	            queue[i - 1] = queue[i];
	        }

	        size--;  // Reduce the size of the queue
	        return highestPriorityValue;
	    }

	    // Peek method to return the element with the highest priority without removing it
	    public int peek() {
	        if (isEmpty()) {
	            throw new IllegalStateException("Queue is empty.");
	        }
	        return queue[0][0];  // Return the value of the element with the highest priority
	    }

	    // Method to check if the queue is empty
	    public boolean isEmpty() {
	        return size == 0;
	    }

	    // Method to print the contents of the queue
	    public String toString() {
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < size; i++) {
	            sb.append("(").append(queue[i][0]).append(", ").append(queue[i][1]).append(") ");
	        }
	        return sb.toString();
	    }

	    public static void main(String[] args) {
	        // Example usage of the PriorityQueue
	        Task2 pq = new Task2();

	        // Enqueue elements with priorities
	        pq.enqueue(30, 2);
	        pq.enqueue(40, 1);
	        pq.enqueue(50, 3);

	        // Print the state of the queue
	        System.out.println("Queue after enqueues: " + pq);

	        // Dequeue elements and show the output
	        System.out.println("Dequeue order:");
	        System.out.println(pq.dequeue());  // Should print 50
	        System.out.println(pq.dequeue());  // Should print 30
	        System.out.println(pq.dequeue());  // Should print 40
	    }
	}
