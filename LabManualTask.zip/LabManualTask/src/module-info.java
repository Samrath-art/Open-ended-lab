/**
 * 
 */
/**
 * 
 */
module LabManualTask {
}