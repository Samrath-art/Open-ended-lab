package Exp7;

public class Task1 {
	
	    private int[] heap;
	    private int size;
	    
	    public Task1(int capacity) {
	        heap = new int[capacity];
	        size = 0;
	    }
	    
	    // Helper method to swap elements
	    private void swap(int i, int j) {
	        int temp = heap[i];
	        heap[i] = heap[j];
	        heap[j] = temp;
	    }
	    
	    // Insert an element into the heap
	    public void insert(int value) {
	        if (size == heap.length) {
	            throw new IllegalStateException("Heap is full");
	        }
	        heap[size] = value;
	        size++;
	        heapifyUp(size - 1);
	    }
	    
	    // Move the element at index up to its correct position
	    private void heapifyUp(int index) {
	        while (index > 0 && heap[index] < heap[(index - 1) / 2]) {
	            swap(index, (index - 1) / 2);
	            index = (index - 1) / 2;
	        }
	    }
	    
	    // Remove the minimum element (root)
	    public int removeMin() {
	        if (size == 0) {
	            throw new IllegalStateException("Heap is empty");
	        }
	        int min = heap[0];
	        heap[0] = heap[size - 1];
	        size--;
	        heapifyDown(0);
	        return min;
	    }
	    
	    // Move the element at index down to its correct position
	    private void heapifyDown(int index) {
	        int leftChild = 2 * index + 1;
	        int rightChild = 2 * index + 2;
	        int smallest = index;
	        
	        if (leftChild < size && heap[leftChild] < heap[smallest]) {
	            smallest = leftChild;
	        }
	        if (rightChild < size && heap[rightChild] < heap[smallest]) {
	            smallest = rightChild;
	        }
	        if (smallest != index) {
	            swap(index, smallest);
	            heapifyDown(smallest);
	        }
	    }
	    
	    // Method to print the heap (for demonstration purposes)
	    public void printHeap() {
	        for (int i = 0; i < size; i++) {
	            System.out.print(heap[i] + " ");
	        }
	        System.out.println();
	    }
	    
	    public static void main(String[] args) {
	        Task1 minHeap = new Task1(10);
	        minHeap.insert(30);
	        minHeap.insert(10);
	        minHeap.insert(20);
	        System.out.print("Heap after insertions: ");
	        minHeap.printHeap();
	        
	        System.out.println("Removed Min: " + minHeap.removeMin());
	        System.out.print("Heap after removal of min: ");
	        minHeap.printHeap();
	    }
	}

