package Exp2;

public class Mergesort{
	    // Method to merge two halves of the array
	    public static void merge(int[] arr, int left, int mid, int right) {
	        // Calculate the size of the two sub-arrays to be merged
	        int n1 = mid - left + 1;
	        int n2 = right - mid;

	        // Temporary arrays for left and right sub-arrays
	        int[] leftArray = new int[n1];
	        int[] rightArray = new int[n2];

	        // Copy data to temporary arrays leftArray and rightArray
	        for (int i = 0; i < n1; i++) {
	            leftArray[i] = arr[left + i];
	        }
	        for (int j = 0; j < n2; j++) {
	            rightArray[j] = arr[mid + 1 + j];
	        }

	        // Merge the temporary arrays back into arr
	        int i = 0, j = 0;
	        int k = left;
	        while (i < n1 && j < n2) {
	            if (leftArray[i] <= rightArray[j]) {
	                arr[k] = leftArray[i];
	                i++;
	            } else {
	                arr[k] = rightArray[j];
	                j++;
	            }
	            k++;
	        }

	        // Copy the remaining elements of leftArray[], if any
	        while (i < n1) {
	            arr[k] = leftArray[i];
	            i++;
	            k++;
	        }

	        // Copy the remaining elements of rightArray[], if any
	        while (j < n2) {
	            arr[k] = rightArray[j];
	            j++;
	            k++;
	        }
	    }

	    public static void mergeSort(int[] arr, int left, int right) {
	        if (left < right) {
	            // Find the middle point of the array
	            int mid = left + (right - left) / 2;

	            // Recursively sort the first and second halves
	            mergeSort(arr, left, mid);
	            mergeSort(arr, mid + 1, right);

	            // Merge the sorted halves
	            merge(arr, left, mid, right);
	        }
	    }

	    // Method to print the array
	    public static void printArray(int[] arr) {
	        for (int i : arr) {
	            System.out.print(i + " ");
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        int[] arr = {38, 27, 43, 3, 9, 82, 10};
	        System.out.println("Original Array:");
	        printArray(arr);

	        mergeSort(arr, 0, arr.length - 1);

	        System.out.println("Sorted Array using Merge Sort:");
	        printArray(arr);
	    }
	}


