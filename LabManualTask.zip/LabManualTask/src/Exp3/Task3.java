package Exp3;

public class Task3 {
	
	    class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    Node head;

	    // Method to add a node at the end of the list
	    public void append(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	            return;
	        }
	        Node current = head;
	        while (current.next != null) {
	            current = current.next;
	        }
	        current.next = newNode;
	    }

	    // Method to create a cycle in the list (for testing purposes)
	    public void createCycle() {
	        if (head == null) return;

	        Node current = head;
	        Node cycleNode = null;
	        int count = 0;
	        // Iterate to find the node at which to start the cycle
	        while (current.next != null) {
	            if (count == 2) {  // Creating a cycle that points back to node with data 20
	                cycleNode = current;
	            }
	            current = current.next;
	            count++;
	        }
	        current.next = cycleNode;  // Creating the cycle
	    }

	    // Method to detect and remove cycle using Floyd's algorithm
	    public void detectAndRemoveCycle() {
	        if (head == null || head.next == null) {
	            System.out.println("The list is too short to have a cycle.");
	            return;
	        }

	        Node slow = head;
	        Node fast = head;
	        boolean hasCycle = false;

	        // Detect the cycle
	        while (fast != null && fast.next != null) {
	            slow = slow.next;
	            fast = fast.next.next;
	            if (slow == fast) {
	                hasCycle = true;
	                break;
	            }
	        }

	        if (!hasCycle) {
	            System.out.println("No cycle detected.");
	            return;
	        }

	        // Find the starting node of the cycle
	        slow = head;
	        while (slow != fast) {
	            slow = slow.next;
	            fast = fast.next;
	        }

	        // Find the last node in the cycle and remove it
	        Node cycleStart = slow;
	        Node current = cycleStart;
	        while (current.next != cycleStart) {
	            current = current.next;
	        }
	        current.next = null;  // Remove the cycle

	        System.out.println("Cycle removed.");
	    }

	    // Method to display the linked list
	    public void printList() {
	        Node current = head;
	        int count = 0;
	        while (current != null && count < 10) { // Limit print to prevent infinite loop
	            System.out.print(current.data + " -> ");
	            current = current.next;
	            count++;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	        Task3 list = new Task3();
	        list.append(10);
	        list.append(20);
	        list.append(30);
	        list.append(40);
	        list.append(50);

	        System.out.println("Input List with Cycle: ");
	        list.createCycle();
	        list.printList();  // Will show the cycle

	        list.detectAndRemoveCycle();
	        System.out.println("Output after Cycle Removal: ");
	        list.printList();  // Output should be cycle-free
	    }
	}


