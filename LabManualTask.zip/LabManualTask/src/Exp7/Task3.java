package Exp7;

public class Task3 {
	
	    private int[] maxHeap; // For the lower half (Max Heap)
	    private int[] minHeap; // For the upper half (Min Heap)
	    private int sizeMaxHeap; // Keeps track of size of maxHeap
	    private int sizeMinHeap; // Keeps track of size of minHeap

	    public Task3() {
	        maxHeap = new int[100]; // Initial capacity for max heap
	        minHeap = new int[100]; // Initial capacity for min heap
	        sizeMaxHeap = 0;
	        sizeMinHeap = 0;
	    }

	    // Insert into the Max Heap (Lower Half)
	    public void insert(int num) {
	        // Step 1: Add to max heap if the number is smaller or equal to the root of max heap
	        if (sizeMaxHeap == 0 || num <= maxHeap[0]) {
	            maxHeap[sizeMaxHeap++] = num;
	            heapifyUpMaxHeap(sizeMaxHeap - 1);
	        } else { // Else, add to the Min Heap (Upper Half)
	            minHeap[sizeMinHeap++] = num;
	            heapifyUpMinHeap(sizeMinHeap - 1);
	        }

	        // Step 2: Balance the heaps
	        if (sizeMaxHeap > sizeMinHeap + 1) {
	            // Move the root of max heap to min heap
	            minHeap[sizeMinHeap++] = maxHeap[0];
	            maxHeap[0] = maxHeap[--sizeMaxHeap];
	            heapifyDownMaxHeap(0);
	            heapifyUpMinHeap(sizeMinHeap - 1);
	        } else if (sizeMinHeap > sizeMaxHeap) {
	            // Move the root of min heap to max heap
	            maxHeap[sizeMaxHeap++] = minHeap[0];
	            minHeap[0] = minHeap[--sizeMinHeap];
	            heapifyDownMinHeap(0);
	            heapifyUpMaxHeap(sizeMaxHeap - 1);
	        }
	    }

	    // Find the current median
	    public double findMedian() {
	        if (sizeMaxHeap > sizeMinHeap) {
	            return maxHeap[0];
	        } else {
	            return (maxHeap[0] + minHeap[0]) / 2.0;
	        }
	    }

	    // Helper methods for max heap (lower half)
	    
	    private void heapifyUpMaxHeap(int index) {
	        while (index > 0 && maxHeap[index] > maxHeap[(index - 1) / 2]) {
	            swap(maxHeap, index, (index - 1) / 2);
	            index = (index - 1) / 2;
	        }
	    }

	    private void heapifyDownMaxHeap(int index) {
	        int largest = index;
	        int left = 2 * index + 1;
	        int right = 2 * index + 2;
	        
	        if (left < sizeMaxHeap && maxHeap[left] > maxHeap[largest]) {
	            largest = left;
	        }
	        
	        if (right < sizeMaxHeap && maxHeap[right] > maxHeap[largest]) {
	            largest = right;
	        }
	        
	        if (largest != index) {
	            swap(maxHeap, index, largest);
	            heapifyDownMaxHeap(largest);
	        }
	    }

	    // Helper methods for min heap (upper half)
	    
	    private void heapifyUpMinHeap(int index) {
	        while (index > 0 && minHeap[index] < minHeap[(index - 1) / 2]) {
	            swap(minHeap, index, (index - 1) / 2);
	            index = (index - 1) / 2;
	        }
	    }

	    private void heapifyDownMinHeap(int index) {
	        int smallest = index;
	        int left = 2 * index + 1;
	        int right = 2 * index + 2;
	        
	        if (left < sizeMinHeap && minHeap[left] < minHeap[smallest]) {
	            smallest = left;
	        }
	        
	        if (right < sizeMinHeap && minHeap[right] < minHeap[smallest]) {
	            smallest = right;
	        }
	        
	        if (smallest != index) {
	            swap(minHeap, index, smallest);
	            heapifyDownMinHeap(smallest);
	        }
	    }

	    // Swap two elements in the heap
	    private void swap(int[] heap, int i, int j) {
	        int temp = heap[i];
	        heap[i] = heap[j];
	        heap[j] = temp;
	    }

	    public static void main(String[] args) {
	        Task3 medianFinder = new Task3();
	        
	        // Inserting elements
	        medianFinder.insert(5);
	        medianFinder.insert(10);
	        medianFinder.insert(15);
	        System.out.println("Median: " + medianFinder.findMedian()); // Should print 10
	        
	        medianFinder.insert(20);
	        System.out.println("Median: " + medianFinder.findMedian()); // Should print 12.5
	        
	        medianFinder.insert(25);
	        System.out.println("Median: " + medianFinder.findMedian()); // Should print 15
	    }
	}

