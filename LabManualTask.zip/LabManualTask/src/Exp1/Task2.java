package Exp1;

public class Task2 {
	public static int[] remove(int [] arr) {
		
		int [] unique=new int[arr.length];
	int uniqueIndex=0;
		for (int i = 0; i < arr.length; i++) {
            // For the first element or if the current element is different from the previous one
            if (i == 0 || arr[i] != arr[i - 1]) {
                unique[uniqueIndex] = arr[i];
                uniqueIndex++;
            }
        }int[] result = new int[uniqueIndex];
        for (int i = 0; i < uniqueIndex; i++) {
            result[i] = unique[i]; // Copy unique elements into the result array
        }
        
        return result; // Return the result array containing only unique elements
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Task2 obj=new Task2();
int [] arr= {1,2,2,3,4,4,5};
int[] unique=obj.remove(arr);
System.out.println("Unique elments array:");
for(int i=0;i<unique.length;i++) {
	System.out.print(unique[i]+" ");
	
}
	}

}
