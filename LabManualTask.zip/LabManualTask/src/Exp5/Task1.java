package Exp5;

public class Task1 {
	

	    // Custom stack implementation using an array
	    static class Stack {
	        char[] stackArray;
	        int top;

	        Stack(int size) {
	            stackArray = new char[size];
	            top = -1;
	        }

	        // Push element to the stack
	        void push(char c) {
	            stackArray[++top] = c;
	        }

	        // Pop element from the stack
	        char pop() {
	            return stackArray[top--];
	        }

	        // Check if the stack is empty
	        boolean isEmpty() {
	            return top == -1;
	        }
	    }

	    public static boolean isBalanced(String expression) {
	        // Create a stack to hold opening brackets
	        Stack stack = new Stack(expression.length());

	        // Traverse through the characters in the expression
	        for (int i = 0; i < expression.length(); i++) {
	            char ch = expression.charAt(i);

	            // If it's an opening bracket, push it to the stack
	            if (ch == '{' || ch == '[' || ch == '(') {
	                stack.push(ch);
	            }
	            // If it's a closing bracket
	            else if (ch == '}' || ch == ']' || ch == ')') {
	                // If stack is empty or the top of stack doesn't match
	                if (stack.isEmpty()) {
	                    return false;
	                }
	                char top = stack.pop();
	                if ((ch == '}' && top != '{') || (ch == ']' && top != '[') || (ch == ')' && top != '(')) {
	                    return false;
	                }
	            }
	        }

	        // If the stack is empty, all brackets were matched
	        return stack.isEmpty();
	    }

	    public static void main(String[] args) {
	        String expression1 = "{[()]}";
	        String expression2 = "{[(])}";

	        System.out.println("Input: " + expression1 + " → " + (isBalanced(expression1) ? "Balanced" : "Not Balanced"));
	        System.out.println("Input: " + expression2 + " → " + (isBalanced(expression2) ? "Balanced" : "Not Balanced"));
	    }
	}


