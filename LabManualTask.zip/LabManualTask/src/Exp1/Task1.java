package Exp1;

public class Task1 {

    // Method to rotate the array by 'k' positions
    public static void rotate(int[] arr, int k) {
        int n = arr.length;  // Get the length of the array

        // If k is greater than the array length, use the remainder of k divided by n
        k = k % n;

        // If k is 0, no rotation is needed, so return
        if (k == 0) {
            return;
        }

        // Reverse the entire array
        reverse(arr, 0, n - 1);

        // Reverse the first part (0 to k-1) to get the correct order
        reverse(arr, 0, k - 1);

        // Reverse the second part (k to n-1) to complete the rotation
        reverse(arr, k, n - 1);
    }

    // Helper method to reverse a portion of the array from 'start' index to 'end' index
    public static void reverse(int[] arr, int start, int end) {
        // Swap elements from both ends towards the middle
        while (start < end) {
            int temp = arr[start];   // Store the element at the 'start' index
            arr[start] = arr[end];   // Swap with the element at the 'end' index
            arr[end] = temp;         // Complete the swap
            start++;                 // Move the 'start' index forward
            end--;                   // Move the 'end' index backward
        }
    }

    public static void main(String[] args) {
        // Sample array to rotate
        int[] arr = {1, 2, 3, 4, 5};
        // Number of positions to rotate the array by
        int k = 2;

        // Print the original array
        System.out.println("Original array:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }

        // Rotate the array by 'k' positions
        rotate(arr, k);

        // Print the array after rotation
        System.out.println("\nArray after rotation by " + k + " positions:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
