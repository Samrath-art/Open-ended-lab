package Exp6;

public class Task1 {
	// Node class to represent each element in the queue
	class Node {
	    int data;
	    Node next;
	    
	    // Constructor to initialize a node with data
	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	// LinkedQueue class implementing the queue using linked list
	
	    private Node front, rear;

	    // Constructor to initialize an empty queue
	    public Task1() {
	        front = rear = null;
	    }

	    // Enqueue operation: Add an element to the rear of the queue
	    public void enqueue(int data) {
	        Node newNode = new Node(data);
	        if (rear == null) {
	            front = rear = newNode; // If the queue is empty, both front and rear point to new node
	        } else {
	            rear.next = newNode; // Add the new node after the current rear
	            rear = newNode; // Update the rear pointer
	        }
	    }

	    // Dequeue operation: Remove an element from the front of the queue
	    public int dequeue() {
	        if (front == null) {
	            throw new IllegalStateException("Queue is empty"); // Cannot dequeue from an empty queue
	        }
	        int data = front.data; // Get the front data
	        front = front.next; // Move the front pointer to the next node
	        if (front == null) {
	            rear = null; // If the queue becomes empty, set rear to null
	        }
	        return data;
	    }

	    // Peek operation: Get the front element without removing it
	    public int peek() {
	        if (front == null) {
	            throw new IllegalStateException("Queue is empty"); // Cannot peek in an empty queue
	        }
	        return front.data;
	    }

	    // isEmpty operation: Check if the queue is empty
	    public boolean isEmpty() {
	        return front == null;
	    }

	    // Main method to test the queue operations
	    public static void main(String[] args) {
	      Task1 queue = new Task1();

	        // Enqueue elements
	        queue.enqueue(10);
	        queue.enqueue(20);

	        // Dequeue one element
	        queue.dequeue();

	        // Peek at the front element
	        System.out.println("Front element after operations: " + queue.peek()); // Expected output: 20
	    }
	}


