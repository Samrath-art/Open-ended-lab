package Exp4;

public class Task3 {
	
	    class Node {
	        int data;
	        Node next;
	        Node prev;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	            this.prev = null;
	        }
	    }

	    Node head;

	    // Method to bubble sort the doubly linked list
	    public void bubbleSort() {
	        if (head == null || head.next == null) {
	            return;  // List is empty or has only one element
	        }

	        boolean swapped;
	        do {
	            swapped = false;
	            Node current = head;

	            while (current != null && current.next != null) {
	                if (current.data > current.next.data) {
	                    // Swap the data by rearranging the next and prev pointers
	                    int temp = current.data;
	                    current.data = current.next.data;
	                    current.next.data = temp;

	                    swapped = true;
	                }
	                current = current.next;
	            }
	        } while (swapped);  // Continue sorting until no more swaps are made
	    }

	    // Method to print the list
	    public void printList() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	       Task3 list = new Task3();
	        list.head = new Task3().new Node(40);
	        list.head.next = new Task3().new Node(20);
	        list.head.next.prev = list.head;
	        list.head.next.next = new Task3().new Node(30);
	        list.head.next.next.prev = list.head.next;
	        list.head.next.next.next = new Task3().new Node(10);
	        list.head.next.next.next.prev = list.head.next.next;

	        System.out.println("Input List: ");
	        list.printList();

	        list.bubbleSort();
	        System.out.println("Sorted List: ");
	        list.printList();  // Expected output: 10 -> 20 -> 30 -> 40 -> null
	    }
	}


