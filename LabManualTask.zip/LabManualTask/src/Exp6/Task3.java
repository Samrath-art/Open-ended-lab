package Exp6;

public class Task3 {
	
	    private int[] queue;
	    private int front;
	    private int rear;
	    private int size;
	    private int capacity;

	    // Constructor to initialize the queue with a given capacity
	    public Task3(int capacity) {
	        this.capacity = capacity;
	        queue = new int[capacity];
	        front = 0;
	        rear = -1;
	        size = 0;
	    }

	    // Enqueue operation to add an element to the queue
	    public void enqueue(int value) {
	        if (size == capacity) {
	            System.out.println("Queue is full");
	            return;
	        }
	        rear = (rear + 1) % capacity;
	        queue[rear] = value;
	        size++;
	    }

	    // Dequeue operation to remove and return the front element
	    public int dequeue() {
	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	            return -1;
	        }
	        int value = queue[front];
	        front = (front + 1) % capacity;
	        size--;
	        return value;
	    }

	    // Peek operation to return the front element without removing it
	    public int peek() {
	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	            return -1;
	        }
	        return queue[front];
	    }

	    // Method to check if the queue is empty
	    public boolean isEmpty() {
	        return size == 0;
	    }

	    // Method to print the queue elements
	    public void printQueue() {
	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	            return;
	        }
	        for (int i = 0; i < size; i++) {
	            System.out.print(queue[(front + i) % capacity] + " -> ");
	        }
	        System.out.println("null");
	    }

	    // Recursive method to reverse the queue
	    public void reverseQueue() {
	        if (isEmpty()) {
	            return;  // Base case: if the queue is empty, stop recursion
	        }
	        // Step 1: Dequeue an element
	        int frontElement = dequeue();
	        
	        // Step 2: Recursively reverse the remaining queue
	        reverseQueue();
	        
	        // Step 3: Enqueue the dequeued element back to the rear of the queue
	        enqueue(frontElement);
	    }
	

	
	    public static void main(String[] args) {
	        // Create a queue with a capacity of 10
	        Task3 queue = new Task3(10);

	        // Enqueue elements to the queue
	        queue.enqueue(10);
	        queue.enqueue(20);
	        queue.enqueue(30);

	        // Print the original queue
	        System.out.print("Original Queue: ");
	        queue.printQueue();

	        // Reverse the queue using recursion
	        queue.reverseQueue();

	        // Print the reversed queue
	        System.out.print("Reversed Queue: ");
	        queue.printQueue();
	    }
	}


